
      <div class="container-fluid">
        <h1 class="mt-4">VetCon Stat</h1>

     <div class="col-xs-6" >

            <div class="row, text-left">

              <a href="<?php echo ("Client") ?>"class="btn btn-success"> New Client </button> </a>

              <a href="<?php echo ("V_Case") ?>" class="btn btn-success"> New Case  </a>

              <a href="<?php echo ("Disease") ?>" class="btn btn-success"> New Disease  </a>

              <a href="<?php echo ("Batch") ?>"class="btn btn-success"> New Batch  </a>

              <a href="<?php echo ("Farm") ?>" class="btn btn-success"> New Farm  </a>

          </div>
      </div>
    </div>
    <!-- /#page-content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Bootstrap core JavaScript -->



